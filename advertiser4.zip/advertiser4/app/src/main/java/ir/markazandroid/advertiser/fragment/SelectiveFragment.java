package ir.markazandroid.advertiser.fragment;

import android.support.v4.app.Fragment;
import android.util.Log;

/**
 * Coded by Ali on 5/24/2018.
 */
public abstract class SelectiveFragment extends Fragment implements OnSelectListener {

    private boolean started=false;

    @Override
    public void onSelect() {
        Log.e("cycle "+toString(),"start");
        if (!started) {
            start();
            started=true;
        }
    }

    @Override
    public void onDeselect() {
        Log.e("cycle "+toString(),"stop");
        if (started) {
            stop();
            started=false;
        }
    }

    protected abstract void start();
    protected abstract void stop();

    public boolean isStarted() {
        return started;
    }

    public void setStarted(boolean started) {
        this.started = started;
    }

    @Override
    public void onResume() {
        super.onResume();
        onSelect();
    }

    @Override
    public void onPause() {
        super.onPause();
        onDeselect();
    }
}
