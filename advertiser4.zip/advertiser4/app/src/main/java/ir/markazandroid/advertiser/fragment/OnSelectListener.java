package ir.markazandroid.advertiser.fragment;

/**
 * Coded by Ali on 06/02/2018.
 */

public interface OnSelectListener {
    void onSelect();
    void onDeselect();
}
