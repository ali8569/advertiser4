package ir.markazandroid.advertiser.util;

import android.content.SharedPreferences;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

/**
 * Coded by Ali on 09/01/2018.
 */

public class PreferencesManager {


    private SharedPreferences sharedPreferences;

    public PreferencesManager(SharedPreferences sharedPreferences){
        this.sharedPreferences=sharedPreferences;
    }
}
