package ir.markazandroid.advertiser.object;


import java.io.Serializable;

import ir.markazandroid.advertiser.network.JSONParser.annotations.JSON;

/**
 * Created by Ali on 8/28/2018.
 */
public class ExtrasObject implements Serializable{

    //Doctor
    private String resumePhotoUrl;
    private String rssFeedUrl;
    private int rssFeedTextSize=21;
    private String tvUrl;

    //4 parts
    private String weatherUrl;
    private String currencyUrl;

    //2 Parts
    private String webViewUrl;

    @JSON
    public String getWebViewUrl() {
        return webViewUrl;
    }

    public void setWebViewUrl(String webViewUrl) {
        this.webViewUrl = webViewUrl;
    }


    @JSON
    public String getResumePhotoUrl() {
        return resumePhotoUrl;
    }

    public void setResumePhotoUrl(String resumePhotoUrl) {
        this.resumePhotoUrl = resumePhotoUrl;
    }

    @JSON
    public String getRssFeedUrl() {
        return rssFeedUrl;
    }

    public void setRssFeedUrl(String rssFeedUrl) {
        this.rssFeedUrl = rssFeedUrl;
    }

    @JSON
    public String getTvUrl() {
        return tvUrl;
    }

    public void setTvUrl(String tvUrl) {
        this.tvUrl = tvUrl;
    }

    @JSON
    public String getWeatherUrl() {
        return weatherUrl;
    }

    public void setWeatherUrl(String weatherUrl) {
        this.weatherUrl = weatherUrl;
    }

    @JSON
    public String getCurrencyUrl() {
        return currencyUrl;
    }

    public void setCurrencyUrl(String currencyUrl) {
        this.currencyUrl = currencyUrl;
    }

    @JSON
    public int getRssFeedTextSize() {
        return rssFeedTextSize;
    }

    public void setRssFeedTextSize(int rssFeedTextSize) {
        this.rssFeedTextSize = rssFeedTextSize;
    }
}
