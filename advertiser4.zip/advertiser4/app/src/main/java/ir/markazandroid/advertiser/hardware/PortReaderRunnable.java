package ir.markazandroid.advertiser.hardware;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;

import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.driver.UsbSerialProber;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import ir.markazandroid.advertiser.AdvertiserApplication;
import ir.markazandroid.advertiser.signal.Signal;
import ir.markazandroid.advertiser.signal.SignalManager;
import ir.markazandroid.advertiser.util.Roozh;
import serial.PortInfo;
import serial.Serial;

/**
 * Coded by Ali on 01/03/2018.
 */

public class PortReaderRunnable implements Runnable {

    private Context context;
    private Handler handler;
    private boolean isBlocked=false;
    private InputParser inputParser;
    private UsbSerialPort port;
    boolean isCancelled =false;
    public static String lastData="NA";
    private Timer timer;

    public PortReaderRunnable(Context context) {
        this.context = context;


        /*for (SerialPort port:ports){
            Log.e("port", "PortReaderRunnable: "+port.getDescriptivePortName()+" : "+port.getSystemPortName() );
        }*/



        handler=new Handler(context.getMainLooper());
        inputParser=new InputParser('$', new InputParser.CommandDetectListener() {
            @Override
            public void onCommandDetected(String cmd) {
                Log.e("command",cmd);
                if(cmd.equals("\r\n"))
                    return;
                /*if(cmd.equals("OFF")){
                    isBlocked=true;
                    sendBlockViewSignal();
                }*/
                lastData=cmd;
                String[] dataArray = cmd.split(";");
                Map<String,String> dataMap = new HashMap<>();
                for(String data:dataArray){
                    String[] d = data.split(":");
                    dataMap.put(d[0],d[1]);
                }
                Log.e("distance",dataMap.get("d")+"  ");
            }
        });
        inputParser.init();


        /*PortInfo[] list = Serial.listPorts();

        for(PortInfo info:list){
            Log.e("port", "PortReaderRunnable: "+info.description+" : "+info.hardwareId+" : "+info.port);
        }*/

        timer=new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                //TODO
               // save(lastData);
            }
        },10_000,10_000);
    }


    @Override
    public void run() {

        final UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
        List<UsbSerialDriver> availableDrivers = UsbSerialProber.getDefaultProber().findAllDrivers(manager);
        if (availableDrivers.isEmpty()) {
            return;
        }


// Open a connection to the first available driver.
        final UsbSerialDriver driver = availableDrivers.get(0);
        final UsbDeviceConnection connection = manager.openDevice(driver.getDevice());
        if (connection == null) {

            handler.post(new Runnable() {
                @Override
                public void run() {
                    PendingIntent mPermissionIntent = PendingIntent.getBroadcast(context, 0, new Intent(ACTION_USB_PERMISSION), 0);
                    IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
                    context.registerReceiver(mUsbReceiver, filter);
                    manager.requestPermission(driver.getDevice(), mPermissionIntent);
                }
            });
            //showToast("NO DRIVER FOUND!");
            // You probably need to call UsbManager.requestPermission(driver.getDevice(), ..)
            return;
        }


// Read some data! Most have just one port (port 0).
        port = driver.getPorts().get(0);


        try {
            port.open(connection);
            port.setParameters(9600, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE);
            byte buffer[] = new byte[1024];
            while (!isCancelled) {
                String read = readChar(port,buffer);
                //Log.e("read",read);
                inputParser.addInput(read);

                //SystemClock.sleep(2000);
                /*if (Integer.parseInt(in.charAt(2)+"")==1)
                    if (!isBlocked) {
                        isBlocked=true;
                        sendBlockViewSignal();
                    }
                else if (isBlocked) {
                        isBlocked=false;
                        sendUnBlockViewSignal();
                    }*/

            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                port.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        /*serialPort.openPort();
        serialPort.setComPortTimeouts(SerialPort.TIMEOUT_READ_SEMI_BLOCKING, 0, 0);
        try {
            while (true)
            {
                byte[] readBuffer = new byte[1024];
                int numRead = serialPort.readBytes(readBuffer, readBuffer.length);
                Log.e("Read",numRead+"");
            }
        } catch (Exception e) { e.printStackTrace(); }
        serialPort.closePort();*/
    }

    public static String readChar(UsbSerialPort port,byte[] buffer) throws IOException {
        int numRead = port.read(buffer, 5000);
        while (numRead<1){
            try {
                Thread.sleep(1);
                numRead = port.read(buffer, 5000);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return new String(buffer,0,numRead);
    }

    /*private void showToast(final String msg){
        handler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(context,msg,Toast.LENGTH_LONG).show();
            }
        });
    }
*/
    private SignalManager getSignalManager(){
        return ((AdvertiserApplication)context.getApplicationContext()).getSignalManager();
    }

    private void sendBlockViewSignal(){
        Signal signal = new Signal("screen block",Signal.SIGNAL_SCREEN_BLOCK);
        getSignalManager().sendMainSignal(signal);
    }

    private void sendUnBlockViewSignal(){
        Signal signal = new Signal("screen unblock",Signal.SIGNAL_SCREEN_UNBLOCK);
        getSignalManager().sendMainSignal(signal);
    }

    private static final String ACTION_USB_PERMISSION =
            "com.android.example.USB_PERMISSION";
    private final BroadcastReceiver mUsbReceiver = new BroadcastReceiver() {

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (ACTION_USB_PERMISSION.equals(action)) {
                synchronized (this) {
                    UsbDevice device = (UsbDevice)intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);

                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        if(device != null){
                            /*PortReaderRunnable portReader = new PortReaderRunnable(context);
                            ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor) Executors.newCachedThreadPool();
                            threadPoolExecutor.execute(portReader);*/
                        }
                    }
                    else {
                        Log.d("tag", "permission denied for device " + device);
                    }
                }
            }
        }
    };

    public void close(){
        try {
            isCancelled=true;
            if (timer!=null)
                timer.cancel();
            if(port!=null)
                port.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    public static void save(String finalBitmap) {

        //getFilesDir()
        //openFileInput()
        //openFileOutput()
        String root = Environment.getExternalStorageDirectory().toString();
        File myDir = new File(root + "/advertiser/logs");
        myDir.mkdirs();
        String fname = Roozh.getCurrentTimeNo()+".txt";
        File file = new File (myDir, fname);
        try {
            FileWriter out =new FileWriter(file,true);
            out.append(Roozh.getTime(System.currentTimeMillis()))
                    .append("  --  ")
                    .append(finalBitmap)
                    .append("\r\n");
            out.flush();
            out.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
