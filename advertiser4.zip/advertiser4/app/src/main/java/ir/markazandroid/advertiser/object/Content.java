package ir.markazandroid.advertiser.object;

import com.google.gson.annotations.JsonAdapter;

import java.io.Serializable;
import java.util.Objects;

import ir.markazandroid.advertiser.network.JSONParser.annotations.JSON;

/**
 * Coded by Ali on 10/21/2018.
 */
public class Content extends Record.Image {
    public static final String TYPE_IMAGE="image";
    public static final String TYPE_VIDEO="video";

    private String url;
    private String type;

    @JSON
    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @JSON
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Content)) return false;

        Content content = (Content) o;

        if (url != null ? !url.equals(content.url) : content.url != null) return false;
        return type != null ? type.equals(content.type) : content.type == null;
    }

    @Override
    public int hashCode() {
        int result = url != null ? url.hashCode() : 0;
        result = 31 * result + (type != null ? type.hashCode() : 0);
        return result;
    }
}
