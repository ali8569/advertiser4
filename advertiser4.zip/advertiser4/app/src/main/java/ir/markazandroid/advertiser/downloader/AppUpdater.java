package ir.markazandroid.advertiser.downloader;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.widget.Toast;

import org.apache.commons.io.FileUtils;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Timer;
import java.util.TimerTask;

import ir.markazandroid.advertiser.AdvertiserApplication;
import ir.markazandroid.advertiser.BuildConfig;
import ir.markazandroid.advertiser.Manifest;
import ir.markazandroid.advertiser.network.JSONParser.Parser;
import ir.markazandroid.advertiser.network.NetStatics;
import ir.markazandroid.advertiser.object.Version;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Coded by Ali on 5/24/2018.
 */
public class AppUpdater {
    private Context context;
    private Timer timer;
    private OkHttpClient client;
    private Parser parser;
    private Handler handler;
    private boolean firstTime=true;

    public AppUpdater(Context context) throws NoSuchMethodException {
        this.context = context;
        this.client = ((AdvertiserApplication)context).getNetworkClient().getClient();
        this.parser=  ((AdvertiserApplication)context).getParser();
        handler=new Handler(context.getMainLooper());
    }

    public void start(){
        stop();
        timer=new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                makeRequest();
                firstTime=false;
            }
        },0,60*1000);
    }

    private void makeRequest() {
        if (!isNetworkConnected() && !firstTime) return;
        Request request = new Request.Builder()
                .url(NetStatics.VERSION)
                .get()
                .build();
        Response response=null;
        try {
            response = client.newCall(request).execute();
            Version version = parser.get(Version.class,new JSONObject(response.body().string()));
            if (version.getVersion()> BuildConfig.VERSION_CODE) {
                downloadNewApp(version.getUrl());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            if (response!=null)
                response.close();
        }
    }

    private void downloadNewApp(String url) throws IOException {
        handler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(context,"نسخه جدید برنامه موجود است. درحال دانلود...",Toast.LENGTH_LONG).show();
            }
        });
        Request request = new Request.Builder()
                .url(url)
                .get()
                .build();
        Response response=null;
        try {
            response = client.newCall(request).execute();
            saveAndInstall(response.body().byteStream());
        } finally {
            if (response!=null)
                response.close();
        }
    }

    private void saveAndInstall(InputStream inputStream) throws IOException {
        File dest = new File(Environment.getExternalStorageDirectory()+"/advertiser/app.apk");
        FileUtils.copyToFile(inputStream,dest);
        final Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(
                Uri.fromFile(dest),
                "application/vnd.android.package-archive");
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        handler.post(new Runnable() {
            @Override
            public void run() {
                context.startActivity(intent);
                stop();
            }
        });
    }

    public void stop() {
        if (timer!=null) timer.cancel();
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        stop();
    }

    private boolean isNetworkConnected(){
        return ((AdvertiserApplication) context.getApplicationContext()).isInternetConnected();
    }
}
