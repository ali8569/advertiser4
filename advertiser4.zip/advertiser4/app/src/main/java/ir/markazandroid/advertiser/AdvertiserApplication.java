package ir.markazandroid.advertiser;

import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;

import com.danikula.videocache.HttpProxyCacheServer;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;
import com.squareup.picasso.OkHttp3Downloader;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.IOException;
import java.util.Locale;

import ir.markazandroid.advertiser.activity.authentication.LoginActivity;
import ir.markazandroid.advertiser.db.DataBase;
import ir.markazandroid.advertiser.downloader.AppUpdater;
import ir.markazandroid.advertiser.downloader.RecordDownloader;
import ir.markazandroid.advertiser.hardware.SensorMeter;
import ir.markazandroid.advertiser.network.JSONParser.Parser;
import ir.markazandroid.advertiser.network.NetworkClient;
import ir.markazandroid.advertiser.object.Content;
import ir.markazandroid.advertiser.object.ErrorObject;
import ir.markazandroid.advertiser.object.ExtrasObject;
import ir.markazandroid.advertiser.object.FieldError;
import ir.markazandroid.advertiser.object.Phone;
import ir.markazandroid.advertiser.object.Record;
import ir.markazandroid.advertiser.object.RecordOptions;
import ir.markazandroid.advertiser.object.User;
import ir.markazandroid.advertiser.object.Version;
import ir.markazandroid.advertiser.signal.Signal;
import ir.markazandroid.advertiser.signal.SignalManager;
import ir.markazandroid.advertiser.signal.SignalReceiver;
import ir.markazandroid.advertiser.util.LocationMgr;
import ir.markazandroid.advertiser.util.PreferencesManager;
import uk.co.chrisjenx.calligraphy.CalligraphyConfig;

import static android.content.pm.ApplicationInfo.FLAG_LARGE_HEAP;

/**
 * Coded by Ali on 01/02/2018.
 */

public class AdvertiserApplication extends Application implements SignalReceiver{

    public static final String SHARED_PREFRENCES = "shared_pref";

    private NetworkClient networkClient;
    private User user;
    private SignalManager signalManager;
    private Parser parser;
    private PreferencesManager preferencesManager;
    private DataBase dataBase;
    private HttpProxyCacheServer proxy;
    private RecordDownloader recordDownloader;
    private boolean isInternetConnected = false;
    private SensorMeter sensorMeter;
    private LocationMgr locationMgr;

    public NetworkClient getNetworkClient(){
        if (networkClient==null){
            networkClient=new NetworkClient(this);
        }
        return networkClient;
    }

    public SignalManager getSignalManager() {
        if (signalManager == null) signalManager = new SignalManager(this);
        return signalManager;
    }

    public HttpProxyCacheServer getProxy() {
        if (proxy==null) {
            proxy = new HttpProxyCacheServer.Builder(this)
                    .build();
        }
        return proxy;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public LocationMgr getLocationMgr() {
        return locationMgr;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        String root = Environment.getExternalStorageDirectory().toString();
        File myDir = new File(root + "/advertiser/image");
        myDir.mkdirs();
        Picasso picasso =new Picasso.Builder(this)
                .downloader(new OkHttp3Downloader(myDir,200_000_000))
                .build();
        Picasso.setSingletonInstance(picasso);
        getSignalManager().addReceiver(this);
        FirebaseMessaging.getInstance().subscribeToTopic("all");

        CalligraphyConfig.Builder config=new CalligraphyConfig.Builder()
                .setFontAttrId(R.attr.fontPath);

        if (!Locale.getDefault().getLanguage().equals("en")){
            config.setDefaultFontPath("font/BYekan.ttf");
        }

        CalligraphyConfig.initDefault(config.build());

        try {
            AppUpdater updater = new AppUpdater(this);
            updater.start();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }

        //locationMgr=new LocationMgr(this);
        //locationMgr.start();

        //sensorMeter=new SensorMeter(this);
        //sensorMeter.init();
    }

    static int calculateMemoryCacheSize(Context context) {
        ActivityManager am = getService(context, ACTIVITY_SERVICE);
        boolean largeHeap = (context.getApplicationInfo().flags & FLAG_LARGE_HEAP) != 0;
        int memoryClass = largeHeap ? am.getLargeMemoryClass() : am.getMemoryClass();
        // Target ~15% of the available heap.
        Log.e("MMCache:", (1024L * 1024L * memoryClass / 6)+"");
        return (int) (1024L * 1024L * memoryClass / 6);
    }

    static <T> T getService(Context context, String service) {
        return (T) context.getSystemService(service);
    }

    public Parser getParser() throws NoSuchMethodException {
        if (parser==null) {
            parser = new Parser();
            parser.addClass(Record.class);
            parser.addClass(Record.Image.class);
            parser.addClass(Record.SubTitle.class);
            parser.addClass(User.class);
            parser.addClass(Phone.class);
            parser.addClass(ErrorObject.class);
            parser.addClass(FieldError.class);
            parser.addClass(Version.class);
            parser.addClass(RecordOptions.class);
            parser.addClass(ExtrasObject.class);
            parser.addSubClass(Content.class);
        }
        return parser;
    }

    public DataBase getDataBase(){
        if (dataBase==null) dataBase=new DataBase(this);
        return dataBase;
    }

    @Override
    public boolean onSignal(Signal signal) {
        if (signal.getType() == Signal.SIGNAL_LOGIN) {
           // setUser((User) signal.getExtras());
            Log.e(AdvertiserApplication.this.toString(), "login signal recived " /*+ user.getUsername()*/);
            return true;
        } else if (signal.getType() == Signal.SIGNAL_LOGOUT) {
            Log.e(AdvertiserApplication.this.toString(), "logout signal recived ");
            getNetworkClient().deleteCookies();
            DeleteToken deleteToken = new DeleteToken();
            deleteToken.execute();
            setUser(null);
            Intent intent = new Intent(this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            return true;
        }
        if (signal.getType()==Signal.DOWNLOADER_NO_NETWORK){
            isInternetConnected=false;
        }else if (signal.getType()==Signal.DOWNLOADER_NETWORK){
            isInternetConnected=true;
        }
        return false;
    }

    public PreferencesManager getPreferencesManager() {
        if (preferencesManager==null) preferencesManager=new PreferencesManager(getSharedPreferences(SHARED_PREFRENCES,MODE_PRIVATE));
        return preferencesManager;
    }

    public RecordDownloader getRecordDownloader() {
        if (recordDownloader==null){
            recordDownloader=new RecordDownloader(this);
        }
        return recordDownloader;
    }

    public boolean isInternetConnected() {
        return isInternetConnected;
    }

    public SensorMeter getSensorMeter() {
        return sensorMeter;
    }

    public void setSensorMeter(SensorMeter sensorMeter) {
        this.sensorMeter = sensorMeter;
    }

    private static class DeleteToken extends AsyncTask {
        @Override
        protected Object doInBackground(Object[] objects) {
            try {
                FirebaseInstanceId.getInstance().deleteInstanceId();
                FirebaseInstanceId.getInstance().getToken();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    @Override
    protected void finalize() throws Throwable {
        getSignalManager().removeReceiver(this);
        sensorMeter.close();
        locationMgr.stop();
    }
}
